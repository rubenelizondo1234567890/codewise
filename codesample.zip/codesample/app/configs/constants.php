<?php
namespace configs;

/**
 * 
 */
class constants
{

const DEFAULTHTTPMETHOD		=	'get';
const DEFAULTHTTPURI		=	'/';
const DEFAULTCONTROLLER		=	'home';
const DEFAULTPAGE			=	'index.php';
const DEFAULTCONTROLLERNAME	=	'home';
const DEFAULTACTIONNAME		=	'index';
const DEFAULTTITLE			=	'R. Elizondo Basic MVC Framework 0.2';
const DEFAULTBASEHTMLVIEW	=	'baseHtml';
const DEFAULTVIEWEXTENSION	=	'rub';
const DS					=	'/';
const DEFAULTAPPDIR			=	'app';
const DEFAULTVIEWDIR		=	'views';
const DEFAULTPROTOCOL		=	'//';
const DEFAULTPORT			=	':80';
const DEFAULTLIMITFORFINDALL	=	'100';
}