<?php
namespace configs;

const DEFAULTHTTPMETHOD		=	'get';
const DEFAULTHTTPURI		=	'/';
const DEFAULTCONTROLLER		=	'home';
const DEFAULTPAGE			=	'index.php';
const DEFAULTCONTROLLERNAME	=	'home';
const DEFAULTACTIONNAME		=	'index';
const DEFAULTTITLE			=	'Code Sample by Ruben E.';
const DEFAULTBASEHTMLVIEW	=	'baseHtml';
const DEFAULTVIEWEXTENSION	=	'rub';
const DS					=	'/';

/**
 * 
 */
class constants
{

}